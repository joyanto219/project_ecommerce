# Build E-commerce app with React js, Vite , Tailwindcss, React router v6

![demo](https://user-images.githubusercontent.com/115061491/228146759-f6ea754f-16cc-4bbd-99f1-ff735bf10aaf.jpg)