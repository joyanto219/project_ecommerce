import {createContext, useState} from 'react';

export const cart_context = createContext()


const CartContext = (children) => {
  const[cart, setCart]=useState([]) 
  const addToCart=(product)=>{
    const selectedProduct = cart.filter((item)=>item.id === product.id)
    if(selectedProduct){
      selectedProduct.quantity = selectedProduct.quantity+1
    }
    const newProduct = {
      ...product,
      quantity:1,
      position:cart.length
    }
    setCart(newProduct)
  }
  const value={
    cart,
    setCart,
  }
  return (
    <cart_context.Provider value={value}>
      {children}
    </cart_context.Provider>
  )
}

export default CartContext